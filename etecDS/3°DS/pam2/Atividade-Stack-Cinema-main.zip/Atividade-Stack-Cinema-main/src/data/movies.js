const DATA =
  [
    {
        id:'01',
        nome:'Adão Negro',
        nota: 4.5,
        imagem:'adao.jpg',

    },
    {
        id:'02',
        nome:'Avatar',
        nota: 7.3,
        imagem:'avatar.jpg'
    },
    {
        id:'03',
        nome:'Desaparecida',
        nota: 8.5,
        imagem:'desaparecida.jpg'
    },
    {
        id:'04',
        nome:'Gato de Botas II',
        nota: 9.8,
        imagem:'gato.jpg'
    },
    {
        id:'05',
        nome:'Homem Formiga III : QuantuMania',
        nota: 5.8,
        imagem:'homemformiga.jpg'
    },
    {
        id:'06',
        nome:'Os incríveis',
        nota: 10,
        imagem:'incriveis.jpg',

    },
    {
        id:'07',
        nome:'Super Mario Bross ',
        nota: 8.0,
        imagem:'mario.jpg'
    },
    {
        id:'08',
        nome:'M3GAN',
        nota: 8.5,
        imagem:'megan.jpg'
    },
    {
        id:'09',
        nome:'Panico VI',
        nota: 6.5,
        imagem:'panico.jpg'
    }
  

]

export default DATA;